import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const isFollowing = query({
  args: { targetUserId: v.id("users") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return false;
    const follow = await ctx.db
      .query("follows")
      .withIndex("by_follower_and_following", (q) =>
        q.eq("followerId", userId).eq("followingId", args.targetUserId)
      )
      .unique();
    return !!follow;
  },
});

export const followUser = mutation({
  args: { targetUserId: v.id("users") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    if (userId === args.targetUserId) return;
    const existing = await ctx.db
      .query("follows")
      .withIndex("by_follower_and_following", (q) =>
        q.eq("followerId", userId).eq("followingId", args.targetUserId)
      )
      .unique();
    if (existing) return;
    await ctx.db.insert("follows", {
      followerId: userId,
      followingId: args.targetUserId,
    });
    const myProfile = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (myProfile) {
      await ctx.db.patch(myProfile._id, { followingCount: myProfile.followingCount + 1 });
    }
    const theirProfile = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", args.targetUserId))
      .unique();
    if (theirProfile) {
      await ctx.db.patch(theirProfile._id, { followersCount: theirProfile.followersCount + 1 });
    }
    await ctx.db.insert("notifications", {
      recipientId: args.targetUserId,
      actorId: userId,
      type: "follow",
      read: false,
    });
  },
});

export const unfollowUser = mutation({
  args: { targetUserId: v.id("users") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const existing = await ctx.db
      .query("follows")
      .withIndex("by_follower_and_following", (q) =>
        q.eq("followerId", userId).eq("followingId", args.targetUserId)
      )
      .unique();
    if (!existing) return;
    await ctx.db.delete(existing._id);
    const myProfile = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (myProfile && myProfile.followingCount > 0) {
      await ctx.db.patch(myProfile._id, { followingCount: myProfile.followingCount - 1 });
    }
    const theirProfile = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", args.targetUserId))
      .unique();
    if (theirProfile && theirProfile.followersCount > 0) {
      await ctx.db.patch(theirProfile._id, { followersCount: theirProfile.followersCount - 1 });
    }
  },
});

export const getFollowers = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const follows = await ctx.db
      .query("follows")
      .withIndex("by_following", (q) => q.eq("followingId", args.userId))
      .collect();
    return Promise.all(
      follows.map(async (f) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_userId", (q) => q.eq("userId", f.followerId))
          .unique();
        return profile
          ? {
              ...profile,
              avatarUrl: profile.avatarId
                ? await ctx.storage.getUrl(profile.avatarId)
                : null,
            }
          : null;
      })
    ).then((r) => r.filter(Boolean));
  },
});

export const getFollowing = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const follows = await ctx.db
      .query("follows")
      .withIndex("by_follower", (q) => q.eq("followerId", args.userId))
      .collect();
    return Promise.all(
      follows.map(async (f) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_userId", (q) => q.eq("userId", f.followingId))
          .unique();
        return profile
          ? {
              ...profile,
              avatarUrl: profile.avatarId
                ? await ctx.storage.getUrl(profile.avatarId)
                : null,
            }
          : null;
      })
    ).then((r) => r.filter(Boolean));
  },
});
