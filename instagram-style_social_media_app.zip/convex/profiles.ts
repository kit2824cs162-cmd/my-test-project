import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getMyProfile = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return null;
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (!profile) return null;
    const avatarUrl = profile.avatarId
      ? await ctx.storage.getUrl(profile.avatarId)
      : null;
    return { ...profile, avatarUrl };
  },
});

export const getProfileByUsername = query({
  args: { username: v.string() },
  handler: async (ctx, args) => {
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_username", (q) => q.eq("username", args.username))
      .unique();
    if (!profile) return null;
    const avatarUrl = profile.avatarId
      ? await ctx.storage.getUrl(profile.avatarId)
      : null;
    return { ...profile, avatarUrl };
  },
});

export const getProfileByUserId = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", args.userId))
      .unique();
    if (!profile) return null;
    const avatarUrl = profile.avatarId
      ? await ctx.storage.getUrl(profile.avatarId)
      : null;
    return { ...profile, avatarUrl };
  },
});

export const ensureProfile = mutation({
  args: { username: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const existing = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (existing) return existing._id;
    const user = await ctx.db.get(userId);
    const username =
      args.username ||
      (user?.email ? user.email.split("@")[0] : "user") +
        Math.floor(Math.random() * 1000);
    const profileId = await ctx.db.insert("profiles", {
      userId,
      username,
      followersCount: 0,
      followingCount: 0,
      postsCount: 0,
    });
    return profileId;
  },
});

export const updateProfile = mutation({
  args: {
    username: v.optional(v.string()),
    bio: v.optional(v.string()),
    website: v.optional(v.string()),
    avatarId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (!profile) throw new Error("Profile not found");
    const updates: Record<string, string | undefined> = {};
    if (args.username !== undefined) updates.username = args.username;
    if (args.bio !== undefined) updates.bio = args.bio;
    if (args.website !== undefined) updates.website = args.website;
    if (args.avatarId !== undefined) updates.avatarId = args.avatarId;
    await ctx.db.patch(profile._id, updates);
  },
});

export const searchUsers = query({
  args: { query: v.string() },
  handler: async (ctx, args) => {
    if (!args.query.trim()) return [];
    const results = await ctx.db
      .query("profiles")
      .withSearchIndex("search_username", (q) =>
        q.search("username", args.query)
      )
      .take(10);
    return Promise.all(
      results.map(async (p) => ({
        ...p,
        avatarUrl: p.avatarId ? await ctx.storage.getUrl(p.avatarId) : null,
      }))
    );
  },
});

export const getSuggestedUsers = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    const profiles = await ctx.db.query("profiles").take(10);
    const filtered = profiles.filter((p) => p.userId !== userId);
    return Promise.all(
      filtered.slice(0, 5).map(async (p) => ({
        ...p,
        avatarUrl: p.avatarId ? await ctx.storage.getUrl(p.avatarId) : null,
      }))
    );
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    return await ctx.storage.generateUploadUrl();
  },
});
