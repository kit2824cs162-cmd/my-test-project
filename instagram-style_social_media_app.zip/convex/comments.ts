import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getComments = query({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const comments = await ctx.db
      .query("comments")
      .withIndex("by_post", (q) => q.eq("postId", args.postId))
      .order("asc")
      .collect();
    return Promise.all(
      comments.map(async (c) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_userId", (q) => q.eq("userId", c.authorId))
          .unique();
        return {
          ...c,
          profile: profile
            ? {
                ...profile,
                avatarUrl: profile.avatarId
                  ? await ctx.storage.getUrl(profile.avatarId)
                  : null,
              }
            : null,
        };
      })
    );
  },
});

export const addComment = mutation({
  args: { postId: v.id("posts"), text: v.string() },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    await ctx.db.insert("comments", {
      postId: args.postId,
      authorId: userId,
      text: args.text,
    });
    const post = await ctx.db.get(args.postId);
    if (post) {
      await ctx.db.patch(args.postId, { commentsCount: post.commentsCount + 1 });
      if (post.authorId !== userId) {
        await ctx.db.insert("notifications", {
          recipientId: post.authorId,
          actorId: userId,
          type: "comment",
          postId: args.postId,
          commentText: args.text,
          read: false,
        });
      }
    }
  },
});

export const deleteComment = mutation({
  args: { commentId: v.id("comments") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const comment = await ctx.db.get(args.commentId);
    if (!comment || comment.authorId !== userId) throw new Error("Unauthorized");
    await ctx.db.delete(args.commentId);
    const post = await ctx.db.get(comment.postId);
    if (post && post.commentsCount > 0) {
      await ctx.db.patch(comment.postId, { commentsCount: post.commentsCount - 1 });
    }
  },
});
