import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getActiveStories = query({
  args: {},
  handler: async (ctx) => {
    const now = Date.now();
    const stories = await ctx.db.query("stories").collect();
    const active = stories.filter((s) => s.expiresAt > now);
    const byUser = new Map<string, typeof active>();
    for (const story of active) {
      const key = story.authorId;
      if (!byUser.has(key)) byUser.set(key, []);
      byUser.get(key)!.push(story);
    }
    return Promise.all(
      Array.from(byUser.entries()).map(async ([userId, userStories]) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_userId", (q) => q.eq("userId", userId as any))
          .unique();
        const imageUrl = await ctx.storage.getUrl(userStories[0].imageId);
        return {
          userId,
          profile: profile
            ? {
                ...profile,
                avatarUrl: profile.avatarId
                  ? await ctx.storage.getUrl(profile.avatarId)
                  : null,
              }
            : null,
          imageUrl,
          count: userStories.length,
        };
      })
    );
  },
});

export const addStory = mutation({
  args: { imageId: v.id("_storage") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000;
    await ctx.db.insert("stories", {
      authorId: userId,
      imageId: args.imageId,
      expiresAt,
    });
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    return await ctx.storage.generateUploadUrl();
  },
});
