import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getFeedPosts = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    const posts = await ctx.db.query("posts").order("desc").take(50);
    return Promise.all(
      posts.map(async (post) => {
        const profile = await ctx.db
          .query("profiles")
          .withIndex("by_userId", (q) => q.eq("userId", post.authorId))
          .unique();
        const imageUrls = await Promise.all(
          post.imageIds.map((id) => ctx.storage.getUrl(id))
        );
        const isLiked = userId
          ? !!(await ctx.db
              .query("likes")
              .withIndex("by_post_and_user", (q) =>
                q.eq("postId", post._id).eq("userId", userId)
              )
              .unique())
          : false;
        const isSaved = userId
          ? !!(await ctx.db
              .query("saves")
              .withIndex("by_post_and_user", (q) =>
                q.eq("postId", post._id).eq("userId", userId)
              )
              .unique())
          : false;
        return {
          ...post,
          imageUrls: imageUrls.filter(Boolean) as string[],
          profile: profile
            ? {
                ...profile,
                avatarUrl: profile.avatarId
                  ? await ctx.storage.getUrl(profile.avatarId)
                  : null,
              }
            : null,
          isLiked,
          isSaved,
        };
      })
    );
  },
});

export const getPostsByUser = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const myUserId = await getAuthUserId(ctx);
    const posts = await ctx.db
      .query("posts")
      .withIndex("by_author", (q) => q.eq("authorId", args.userId))
      .order("desc")
      .collect();
    return Promise.all(
      posts.map(async (post) => {
        const imageUrls = await Promise.all(
          post.imageIds.map((id) => ctx.storage.getUrl(id))
        );
        const isLiked = myUserId
          ? !!(await ctx.db
              .query("likes")
              .withIndex("by_post_and_user", (q) =>
                q.eq("postId", post._id).eq("userId", myUserId)
              )
              .unique())
          : false;
        const isSaved = myUserId
          ? !!(await ctx.db
              .query("saves")
              .withIndex("by_post_and_user", (q) =>
                q.eq("postId", post._id).eq("userId", myUserId)
              )
              .unique())
          : false;
        return {
          ...post,
          imageUrls: imageUrls.filter(Boolean) as string[],
          isLiked,
          isSaved,
        };
      })
    );
  },
});

export const getSavedPosts = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    const saves = await ctx.db
      .query("saves")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .order("desc")
      .collect();
    return Promise.all(
      saves.map(async (save) => {
        const post = await ctx.db.get(save.postId);
        if (!post) return null;
        const imageUrls = await Promise.all(
          post.imageIds.map((id) => ctx.storage.getUrl(id))
        );
        return { ...post, imageUrls: imageUrls.filter(Boolean) as string[], isLiked: false, isSaved: true };
      })
    ).then((r) => r.filter(Boolean));
  },
});

export const createPost = mutation({
  args: {
    caption: v.optional(v.string()),
    imageIds: v.array(v.id("_storage")),
    location: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const postId = await ctx.db.insert("posts", {
      authorId: userId,
      caption: args.caption,
      imageIds: args.imageIds,
      location: args.location,
      likesCount: 0,
      commentsCount: 0,
    });
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (profile) {
      await ctx.db.patch(profile._id, { postsCount: profile.postsCount + 1 });
    }
    return postId;
  },
});

export const deletePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const post = await ctx.db.get(args.postId);
    if (!post || post.authorId !== userId) throw new Error("Unauthorized");
    await ctx.db.delete(args.postId);
    const profile = await ctx.db
      .query("profiles")
      .withIndex("by_userId", (q) => q.eq("userId", userId))
      .unique();
    if (profile && profile.postsCount > 0) {
      await ctx.db.patch(profile._id, { postsCount: profile.postsCount - 1 });
    }
  },
});

export const editPost = mutation({
  args: { postId: v.id("posts"), caption: v.optional(v.string()), location: v.optional(v.string()) },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const post = await ctx.db.get(args.postId);
    if (!post || post.authorId !== userId) throw new Error("Unauthorized");
    await ctx.db.patch(args.postId, { caption: args.caption, location: args.location });
  },
});

export const likePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const existing = await ctx.db
      .query("likes")
      .withIndex("by_post_and_user", (q) =>
        q.eq("postId", args.postId).eq("userId", userId)
      )
      .unique();
    if (existing) return;
    await ctx.db.insert("likes", { postId: args.postId, userId });
    const post = await ctx.db.get(args.postId);
    if (post) {
      await ctx.db.patch(args.postId, { likesCount: post.likesCount + 1 });
      if (post.authorId !== userId) {
        await ctx.db.insert("notifications", {
          recipientId: post.authorId,
          actorId: userId,
          type: "like",
          postId: args.postId,
          read: false,
        });
      }
    }
  },
});

export const unlikePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const existing = await ctx.db
      .query("likes")
      .withIndex("by_post_and_user", (q) =>
        q.eq("postId", args.postId).eq("userId", userId)
      )
      .unique();
    if (!existing) return;
    await ctx.db.delete(existing._id);
    const post = await ctx.db.get(args.postId);
    if (post && post.likesCount > 0) {
      await ctx.db.patch(args.postId, { likesCount: post.likesCount - 1 });
    }
  },
});

export const savePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const existing = await ctx.db
      .query("saves")
      .withIndex("by_post_and_user", (q) =>
        q.eq("postId", args.postId).eq("userId", userId)
      )
      .unique();
    if (existing) return;
    await ctx.db.insert("saves", { postId: args.postId, userId });
  },
});

export const unsavePost = mutation({
  args: { postId: v.id("posts") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const existing = await ctx.db
      .query("saves")
      .withIndex("by_post_and_user", (q) =>
        q.eq("postId", args.postId).eq("userId", userId)
      )
      .unique();
    if (existing) await ctx.db.delete(existing._id);
  },
});

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    return await ctx.storage.generateUploadUrl();
  },
});
