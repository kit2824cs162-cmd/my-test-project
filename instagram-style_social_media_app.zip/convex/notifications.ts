import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const getNotifications = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    const notifs = await ctx.db
      .query("notifications")
      .withIndex("by_recipient", (q) => q.eq("recipientId", userId))
      .order("desc")
      .take(30);
    return Promise.all(
      notifs.map(async (n) => {
        const actorProfile = await ctx.db
          .query("profiles")
          .withIndex("by_userId", (q) => q.eq("userId", n.actorId))
          .unique();
        const post = n.postId ? await ctx.db.get(n.postId) : null;
        const postImageUrl =
          post && post.imageIds[0]
            ? await ctx.storage.getUrl(post.imageIds[0])
            : null;
        return {
          ...n,
          actorProfile: actorProfile
            ? {
                ...actorProfile,
                avatarUrl: actorProfile.avatarId
                  ? await ctx.storage.getUrl(actorProfile.avatarId)
                  : null,
              }
            : null,
          postImageUrl,
        };
      })
    );
  },
});

export const getUnreadCount = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return 0;
    const unread = await ctx.db
      .query("notifications")
      .withIndex("by_recipient_and_read", (q) =>
        q.eq("recipientId", userId).eq("read", false)
      )
      .collect();
    return unread.length;
  },
});

export const markAllRead = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");
    const unread = await ctx.db
      .query("notifications")
      .withIndex("by_recipient_and_read", (q) =>
        q.eq("recipientId", userId).eq("read", false)
      )
      .collect();
    await Promise.all(unread.map((n) => ctx.db.patch(n._id, { read: true })));
  },
});
