import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  profiles: defineTable({
    userId: v.id("users"),
    username: v.string(),
    bio: v.optional(v.string()),
    website: v.optional(v.string()),
    avatarId: v.optional(v.id("_storage")),
    followersCount: v.number(),
    followingCount: v.number(),
    postsCount: v.number(),
  })
    .index("by_userId", ["userId"])
    .index("by_username", ["username"])
    .searchIndex("search_username", { searchField: "username" }),

  posts: defineTable({
    authorId: v.id("users"),
    caption: v.optional(v.string()),
    imageIds: v.array(v.id("_storage")),
    likesCount: v.number(),
    commentsCount: v.number(),
    location: v.optional(v.string()),
  }).index("by_author", ["authorId"]),

  likes: defineTable({
    postId: v.id("posts"),
    userId: v.id("users"),
  })
    .index("by_post", ["postId"])
    .index("by_user", ["userId"])
    .index("by_post_and_user", ["postId", "userId"]),

  comments: defineTable({
    postId: v.id("posts"),
    authorId: v.id("users"),
    text: v.string(),
  }).index("by_post", ["postId"]),

  saves: defineTable({
    postId: v.id("posts"),
    userId: v.id("users"),
  })
    .index("by_user", ["userId"])
    .index("by_post_and_user", ["postId", "userId"]),

  follows: defineTable({
    followerId: v.id("users"),
    followingId: v.id("users"),
  })
    .index("by_follower", ["followerId"])
    .index("by_following", ["followingId"])
    .index("by_follower_and_following", ["followerId", "followingId"]),

  notifications: defineTable({
    recipientId: v.id("users"),
    actorId: v.id("users"),
    type: v.union(
      v.literal("like"),
      v.literal("comment"),
      v.literal("follow")
    ),
    postId: v.optional(v.id("posts")),
    commentText: v.optional(v.string()),
    read: v.boolean(),
  })
    .index("by_recipient", ["recipientId"])
    .index("by_recipient_and_read", ["recipientId", "read"]),

  stories: defineTable({
    authorId: v.id("users"),
    imageId: v.id("_storage"),
    expiresAt: v.number(),
  }).index("by_author", ["authorId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
