import { createContext, useContext, useState } from "react";

type Page =
  | "home"
  | "explore"
  | "reels"
  | "notifications"
  | "create"
  | "profile"
  | "search"
  | "saved"
  | "settings";

type NavigationContextType = {
  currentPage: Page;
  navigate: (page: Page, params?: Record<string, string>) => void;
  params: Record<string, string>;
  profileUsername: string | null;
  setProfileUsername: (u: string | null) => void;
};

const NavigationContext = createContext<NavigationContextType>({
  currentPage: "home",
  navigate: () => {},
  params: {},
  profileUsername: null,
  setProfileUsername: () => {},
});

export function NavigationProvider({ children }: { children: React.ReactNode }) {
  const [currentPage, setCurrentPage] = useState<Page>("home");
  const [params, setParams] = useState<Record<string, string>>({});
  const [profileUsername, setProfileUsername] = useState<string | null>(null);

  const navigate = (page: Page, newParams?: Record<string, string>) => {
    setCurrentPage(page);
    setParams(newParams || {});
  };

  return (
    <NavigationContext.Provider
      value={{ currentPage, navigate, params, profileUsername, setProfileUsername }}
    >
      {children}
    </NavigationContext.Provider>
  );
}

export const useNavigation = () => useContext(NavigationContext);
