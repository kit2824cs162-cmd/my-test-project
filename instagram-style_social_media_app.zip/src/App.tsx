import { Authenticated, Unauthenticated, useQuery, useMutation } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { Toaster } from "sonner";
import { useEffect, useState } from "react";
import { MainLayout } from "./components/MainLayout";
import { ThemeProvider } from "./context/ThemeContext";
import { NavigationProvider } from "./context/NavigationContext";

export default function App() {
  return (
    <ThemeProvider>
      <NavigationProvider>
        <div className="min-h-screen">
          <Authenticated>
            <AuthenticatedApp />
          </Authenticated>
          <Unauthenticated>
            <AuthPage />
          </Unauthenticated>
          <Toaster position="top-center" />
        </div>
      </NavigationProvider>
    </ThemeProvider>
  );
}

function AuthenticatedApp() {
  const ensureProfile = useMutation(api.profiles.ensureProfile);
  const loggedInUser = useQuery(api.auth.loggedInUser);

  useEffect(() => {
    if (loggedInUser) {
      const username = loggedInUser.email
        ? loggedInUser.email.split("@")[0]
        : "user" + Math.floor(Math.random() * 9999);
      ensureProfile({ username }).catch(() => {});
    }
  }, [loggedInUser]);

  return <MainLayout />;
}

function AuthPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-black px-4">
      <div className="w-full max-w-sm">
        <div className="bg-white dark:bg-neutral-900 border border-gray-200 dark:border-neutral-700 rounded-sm p-10 mb-3">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold" style={{ fontFamily: "cursive" }}>
              Instaclone
            </h1>
          </div>
          <SignInForm />
        </div>
        <div className="bg-white dark:bg-neutral-900 border border-gray-200 dark:border-neutral-700 rounded-sm p-6 text-center text-sm">
          Don't have an account?{" "}
          <span className="text-blue-500 font-semibold cursor-pointer">Sign up</span>
        </div>
      </div>
    </div>
  );
}
