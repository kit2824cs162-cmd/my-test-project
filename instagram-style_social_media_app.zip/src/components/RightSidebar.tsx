import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Avatar } from "./Avatar";
import { useNavigation } from "../context/NavigationContext";
import { useAuthActions } from "@convex-dev/auth/react";

export function RightSidebar() {
  const myProfile = useQuery(api.profiles.getMyProfile);
  const suggested = useQuery(api.profiles.getSuggestedUsers);
  const followUser = useMutation(api.follows.followUser);
  const { navigate, setProfileUsername } = useNavigation();
  const { signOut } = useAuthActions();

  return (
    <div className="sticky top-6 pt-6">
      {/* My profile */}
      {myProfile && (
        <div className="flex items-center justify-between mb-6">
          <button
            className="flex items-center gap-3"
            onClick={() => { setProfileUsername(myProfile.username); navigate("profile"); }}
          >
            <Avatar src={myProfile.avatarUrl} username={myProfile.username} size={44} />
            <div className="text-left">
              <p className="text-sm font-semibold">{myProfile.username}</p>
              <p className="text-xs text-gray-500">{myProfile.bio || "Your profile"}</p>
            </div>
          </button>
          <button onClick={() => signOut()} className="text-xs text-blue-500 font-semibold hover:text-blue-700">
            Log out
          </button>
        </div>
      )}

      {/* Suggestions */}
      {suggested && suggested.length > 0 && (
        <div>
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm font-semibold text-gray-500">Suggested for you</span>
            <button className="text-xs font-semibold hover:opacity-60">See All</button>
          </div>
          <div className="flex flex-col gap-3">
            {suggested.map((profile) => (
              <div key={profile._id} className="flex items-center justify-between">
                <button
                  className="flex items-center gap-3"
                  onClick={() => { setProfileUsername(profile.username); navigate("profile"); }}
                >
                  <Avatar src={profile.avatarUrl} username={profile.username} size={32} />
                  <div className="text-left">
                    <p className="text-sm font-semibold">{profile.username}</p>
                    <p className="text-xs text-gray-500">Suggested for you</p>
                  </div>
                </button>
                <button
                  onClick={() => followUser({ targetUserId: profile.userId })}
                  className="text-xs text-blue-500 font-semibold hover:text-blue-700"
                >
                  Follow
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="mt-6 text-xs text-gray-400 space-y-1">
        <p>About · Help · Press · API · Jobs · Privacy · Terms</p>
        <p>© 2024 Instaclone</p>
      </div>
    </div>
  );
}
