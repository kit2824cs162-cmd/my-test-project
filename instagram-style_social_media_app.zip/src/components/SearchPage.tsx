import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Search } from "lucide-react";
import { Avatar } from "./Avatar";
import { useNavigation } from "../context/NavigationContext";

export function SearchPage() {
  const [query, setQuery] = useState("");
  const results = useQuery(api.profiles.searchUsers, query.trim() ? { query } : "skip");
  const { navigate, setProfileUsername } = useNavigation();

  return (
    <div className="max-w-[600px] mx-auto px-4 py-6 pb-20 md:pb-6">
      <div className="relative mb-6">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search"
          className="w-full pl-9 pr-4 py-2 bg-gray-100 dark:bg-neutral-800 rounded-lg text-sm outline-none"
        />
      </div>

      {query.trim() === "" ? (
        <div className="text-center py-16 text-gray-400">
          <Search size={48} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm">Search for people</p>
        </div>
      ) : results === undefined ? (
        <div className="flex flex-col gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 animate-pulse">
              <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-neutral-700" />
              <div className="h-3 w-32 bg-gray-200 dark:bg-neutral-700 rounded" />
            </div>
          ))}
        </div>
      ) : results.length === 0 ? (
        <p className="text-center text-gray-400 text-sm py-8">No results for "{query}"</p>
      ) : (
        <div className="flex flex-col gap-1">
          {results.map((profile) => (
            <button
              key={profile._id}
              className="flex items-center gap-3 px-2 py-3 rounded-lg hover:bg-gray-50 dark:hover:bg-neutral-900 w-full text-left"
              onClick={() => {
                setProfileUsername(profile.username);
                navigate("profile");
              }}
            >
              <Avatar src={profile.avatarUrl} username={profile.username} size={44} />
              <div>
                <p className="text-sm font-semibold">{profile.username}</p>
                {profile.bio && <p className="text-xs text-gray-500 truncate max-w-[200px]">{profile.bio}</p>}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
