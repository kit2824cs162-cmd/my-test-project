import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useNavigation } from "../context/NavigationContext";
import { Avatar } from "./Avatar";
import { Grid, Bookmark, Settings, UserCheck, UserPlus } from "lucide-react";
import { useState } from "react";
import { PostCard } from "./PostCard";
import { EditProfileModal } from "./EditProfileModal";
import { toast } from "sonner";

export function ProfilePage() {
  const { profileUsername } = useNavigation();
  const myProfile = useQuery(api.profiles.getMyProfile);
  const targetProfile = useQuery(
    api.profiles.getProfileByUsername,
    profileUsername ? { username: profileUsername } : "skip"
  );
  const isLoadingProfile = profileUsername ? targetProfile === undefined : myProfile === undefined;
  const profile = profileUsername ? targetProfile : myProfile;
  const posts = useQuery(
    api.posts.getPostsByUser,
    profile?.userId ? { userId: profile.userId } : "skip"
  );
  const savedPosts = useQuery(api.posts.getSavedPosts);
  const isFollowing = useQuery(
    api.follows.isFollowing,
    profile?.userId && profile.userId !== myProfile?.userId
      ? { targetUserId: profile.userId }
      : "skip"
  );
  const followUser = useMutation(api.follows.followUser);
  const unfollowUser = useMutation(api.follows.unfollowUser);
  const [tab, setTab] = useState<"posts" | "saved">("posts");
  const [showEdit, setShowEdit] = useState(false);

  const isOwnProfile = !profileUsername || profile?.userId === myProfile?.userId;

  if (isLoadingProfile) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-gray-400" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="flex items-center justify-center h-64 text-gray-400">
        <p>Profile not found.</p>
      </div>
    );
  }

  const handleFollow = async () => {
    if (!profile.userId) return;
    if (isFollowing) {
      await unfollowUser({ targetUserId: profile.userId });
      toast.success(`Unfollowed ${profile.username}`);
    } else {
      await followUser({ targetUserId: profile.userId });
      toast.success(`Following ${profile.username}`);
    }
  };

  const displayPosts = tab === "posts" ? posts : savedPosts;

  return (
    <div className="max-w-[935px] mx-auto px-4 py-8 pb-20 md:pb-8">
      {/* Profile header */}
      <div className="flex flex-col md:flex-row items-center md:items-start gap-8 mb-10">
        <div className="flex-shrink-0">
          <Avatar src={profile.avatarUrl} username={profile.username} size={96} ring={!!profile.avatarUrl} />
        </div>
        <div className="flex-1 text-center md:text-left">
          <div className="flex flex-col md:flex-row items-center md:items-center gap-4 mb-4">
            <h1 className="text-xl font-light">{profile.username}</h1>
            {isOwnProfile ? (
              <div className="flex gap-2">
                <button
                  onClick={() => setShowEdit(true)}
                  className="px-4 py-1.5 bg-gray-100 dark:bg-neutral-800 rounded-lg text-sm font-semibold hover:bg-gray-200 dark:hover:bg-neutral-700"
                >
                  Edit profile
                </button>
                <button className="p-1.5 bg-gray-100 dark:bg-neutral-800 rounded-lg hover:bg-gray-200 dark:hover:bg-neutral-700">
                  <Settings size={18} />
                </button>
              </div>
            ) : (
              <button
                onClick={handleFollow}
                className={`flex items-center gap-2 px-4 py-1.5 rounded-lg text-sm font-semibold transition-colors ${
                  isFollowing
                    ? "bg-gray-100 dark:bg-neutral-800 hover:bg-gray-200 dark:hover:bg-neutral-700"
                    : "bg-blue-500 text-white hover:bg-blue-600"
                }`}
              >
                {isFollowing ? <UserCheck size={16} /> : <UserPlus size={16} />}
                {isFollowing ? "Following" : "Follow"}
              </button>
            )}
          </div>

          <div className="flex justify-center md:justify-start gap-8 mb-4">
            <div className="text-center md:text-left">
              <span className="font-semibold">{profile.postsCount}</span>
              <span className="text-sm ml-1">posts</span>
            </div>
            <div className="text-center md:text-left">
              <span className="font-semibold">{profile.followersCount}</span>
              <span className="text-sm ml-1">followers</span>
            </div>
            <div className="text-center md:text-left">
              <span className="font-semibold">{profile.followingCount}</span>
              <span className="text-sm ml-1">following</span>
            </div>
          </div>

          {profile.bio && <p className="text-sm whitespace-pre-wrap">{profile.bio}</p>}
          {profile.website && (
            <a href={profile.website} className="text-sm text-blue-900 dark:text-blue-400 font-semibold" target="_blank" rel="noreferrer">
              {profile.website}
            </a>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="border-t border-gray-200 dark:border-neutral-800 flex justify-center gap-12 mb-6">
        <button
          onClick={() => setTab("posts")}
          className={`flex items-center gap-2 py-3 text-xs font-semibold tracking-widest uppercase border-t-2 -mt-px transition-colors ${
            tab === "posts" ? "border-black dark:border-white" : "border-transparent text-gray-400"
          }`}
        >
          <Grid size={14} /> Posts
        </button>
        {isOwnProfile && (
          <button
            onClick={() => setTab("saved")}
            className={`flex items-center gap-2 py-3 text-xs font-semibold tracking-widest uppercase border-t-2 -mt-px transition-colors ${
              tab === "saved" ? "border-black dark:border-white" : "border-transparent text-gray-400"
            }`}
          >
            <Bookmark size={14} /> Saved
          </button>
        )}
      </div>

      {/* Posts grid */}
      {displayPosts === undefined ? (
        <div className="grid grid-cols-3 gap-1">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className="aspect-square bg-gray-200 dark:bg-neutral-800 animate-pulse" />
          ))}
        </div>
      ) : displayPosts.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <p className="text-lg font-semibold">No posts yet</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-1">
          {displayPosts.map((post) =>
            post ? (
              <div key={post._id} className="aspect-square overflow-hidden cursor-pointer relative group">
                {post.imageUrls[0] ? (
                  <img src={post.imageUrls[0]} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gray-200 dark:bg-neutral-800" />
                )}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 text-white">
                  <span className="flex items-center gap-1 font-semibold">
                    ♥ {post.likesCount}
                  </span>
                  <span className="flex items-center gap-1 font-semibold">
                    💬 {post.commentsCount}
                  </span>
                </div>
              </div>
            ) : null
          )}
        </div>
      )}

      {showEdit && <EditProfileModal onClose={() => setShowEdit(false)} />}
    </div>
  );
}
