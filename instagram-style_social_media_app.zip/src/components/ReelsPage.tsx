export function ReelsPage() {
  return (
    <div className="flex items-center justify-center h-screen text-gray-400">
      <div className="text-center">
        <p className="text-4xl mb-3">🎬</p>
        <p className="text-lg font-semibold">Reels</p>
        <p className="text-sm mt-1">Coming soon</p>
      </div>
    </div>
  );
}
