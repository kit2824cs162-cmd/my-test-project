import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { PostCard } from "./PostCard";
import { StoriesBar } from "./StoriesBar";
import { RightSidebar } from "./RightSidebar";

export function HomeFeed() {
  const posts = useQuery(api.posts.getFeedPosts);

  return (
    <div className="flex justify-center gap-8 px-4 py-6 pb-20 md:pb-6">
      <div className="w-full max-w-[470px]">
        <StoriesBar />
        <div className="flex flex-col gap-6 mt-4">
          {posts === undefined ? (
            Array.from({ length: 3 }).map((_, i) => (
              <div key={i} className="bg-white dark:bg-neutral-900 border border-gray-200 dark:border-neutral-800 rounded-sm animate-pulse">
                <div className="flex items-center gap-3 p-3">
                  <div className="w-8 h-8 rounded-full bg-gray-200 dark:bg-neutral-700" />
                  <div className="h-3 w-24 bg-gray-200 dark:bg-neutral-700 rounded" />
                </div>
                <div className="w-full aspect-square bg-gray-200 dark:bg-neutral-700" />
                <div className="p-3 space-y-2">
                  <div className="h-3 w-16 bg-gray-200 dark:bg-neutral-700 rounded" />
                  <div className="h-3 w-48 bg-gray-200 dark:bg-neutral-700 rounded" />
                </div>
              </div>
            ))
          ) : posts.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <p className="text-lg font-semibold">No posts yet</p>
              <p className="text-sm mt-1">Be the first to share something!</p>
            </div>
          ) : (
            posts.map((post) => <PostCard key={post._id} post={post} />)
          )}
        </div>
      </div>
      <div className="hidden lg:block w-[320px] flex-shrink-0">
        <RightSidebar />
      </div>
    </div>
  );
}
