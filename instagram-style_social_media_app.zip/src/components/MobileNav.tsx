import { useNavigation } from "../context/NavigationContext";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Home, Search, PlusSquare, Film, Heart } from "lucide-react";
import { Avatar } from "./Avatar";

interface MobileNavProps {
  onCreatePost: () => void;
}

export function MobileNav({ onCreatePost }: MobileNavProps) {
  const { currentPage, navigate, setProfileUsername } = useNavigation();
  const myProfile = useQuery(api.profiles.getMyProfile);
  const unreadCount = useQuery(api.notifications.getUnreadCount);

  const items = [
    { id: "home", icon: Home },
    { id: "search", icon: Search },
    { id: "create", icon: PlusSquare },
    { id: "reels", icon: Film },
    { id: "notifications", icon: Heart, badge: unreadCount },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-white dark:bg-black border-t border-gray-200 dark:border-neutral-800 flex md:hidden">
      {items.map(({ id, icon: Icon, badge }) => (
        <button
          key={id}
          onClick={() => {
            if (id === "create") onCreatePost();
            else navigate(id as any);
          }}
          className="flex-1 flex items-center justify-center py-3 relative"
        >
          <Icon size={24} strokeWidth={currentPage === id ? 2.5 : 1.5} />
          {badge ? (
            <span className="absolute top-2 right-1/4 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
              {badge > 9 ? "9+" : badge}
            </span>
          ) : null}
        </button>
      ))}
      <button
        onClick={() => {
          setProfileUsername(myProfile?.username || null);
          navigate("profile");
        }}
        className="flex-1 flex items-center justify-center py-3"
      >
        <Avatar src={myProfile?.avatarUrl ?? null} username={myProfile?.username ?? "?"} size={24} />
      </button>
    </nav>
  );
}
