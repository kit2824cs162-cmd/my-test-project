import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Avatar } from "./Avatar";
import { useNavigation } from "../context/NavigationContext";

export function StoriesBar() {
  const stories = useQuery(api.stories.getActiveStories);
  const myProfile = useQuery(api.profiles.getMyProfile);
  const { navigate, setProfileUsername } = useNavigation();

  return (
    <div className="bg-white dark:bg-black border border-gray-200 dark:border-neutral-800 rounded-sm p-4 overflow-x-auto">
      <div className="flex gap-4 min-w-0">
        {myProfile && (
          <div className="flex flex-col items-center gap-1 cursor-pointer flex-shrink-0"
            onClick={() => { setProfileUsername(myProfile.username); navigate("profile"); }}>
            <div className="relative">
              <Avatar src={myProfile.avatarUrl} username={myProfile.username} size={56} ring />
              <div className="absolute bottom-0 right-0 w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center border-2 border-white dark:border-black">
                <span className="text-white text-xs font-bold">+</span>
              </div>
            </div>
            <span className="text-xs text-gray-500 truncate w-14 text-center">Your story</span>
          </div>
        )}
        {stories?.map((story) => (
          <div key={story.userId} className="flex flex-col items-center gap-1 cursor-pointer flex-shrink-0"
            onClick={() => { setProfileUsername(story.profile?.username || null); navigate("profile"); }}>
            <Avatar
              src={story.profile?.avatarUrl}
              username={story.profile?.username || "?"}
              size={56}
              ring
            />
            <span className="text-xs truncate w-14 text-center">{story.profile?.username}</span>
          </div>
        ))}
        {(!stories || stories.length === 0) && (
          <div className="flex gap-4">
            {["alice", "bob", "carol", "dave", "eve"].map((name) => (
              <div key={name} className="flex flex-col items-center gap-1 flex-shrink-0">
                <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 p-0.5">
                  <div className="w-full h-full rounded-full bg-gray-200 dark:bg-neutral-700 flex items-center justify-center">
                    <span className="text-sm font-semibold">{name[0].toUpperCase()}</span>
                  </div>
                </div>
                <span className="text-xs text-gray-500 truncate w-14 text-center">{name}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
