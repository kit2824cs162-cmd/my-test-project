import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { X, Heart, Send } from "lucide-react";
import { useState } from "react";
import { Avatar } from "./Avatar";
import { useNavigation } from "../context/NavigationContext";

interface CommentsModalProps {
  post: {
    _id: Id<"posts">;
    imageUrls: string[];
    caption?: string;
    likesCount: number;
    isLiked: boolean;
    profile: { username: string; avatarUrl: string | null } | null;
  };
  onClose: () => void;
}

export function CommentsModal({ post, onClose }: CommentsModalProps) {
  const comments = useQuery(api.comments.getComments, { postId: post._id });
  const addComment = useMutation(api.comments.addComment);
  const deleteComment = useMutation(api.comments.deleteComment);
  const myProfile = useQuery(api.profiles.getMyProfile);
  const likePost = useMutation(api.posts.likePost);
  const unlikePost = useMutation(api.posts.unlikePost);
  const { navigate, setProfileUsername } = useNavigation();
  const [text, setText] = useState("");
  const [isLiked, setIsLiked] = useState(post.isLiked);
  const [likesCount, setLikesCount] = useState(post.likesCount);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    await addComment({ postId: post._id, text: text.trim() });
    setText("");
  };

  const handleLike = async () => {
    if (isLiked) {
      setIsLiked(false);
      setLikesCount((c) => c - 1);
      await unlikePost({ postId: post._id });
    } else {
      setIsLiked(true);
      setLikesCount((c) => c + 1);
      await likePost({ postId: post._id });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <div
        className="bg-white dark:bg-neutral-900 rounded-lg overflow-hidden flex w-full max-w-4xl max-h-[90vh] relative"
        onClick={(e) => e.stopPropagation()}
      >
        <button onClick={onClose} className="absolute top-3 right-3 z-10 text-white bg-black/50 rounded-full p-1">
          <X size={18} />
        </button>

        {/* Image */}
        <div className="hidden md:flex w-[55%] bg-black items-center justify-center">
          {post.imageUrls[0] ? (
            <img src={post.imageUrls[0]} alt="Post" className="w-full h-full object-contain max-h-[90vh]" />
          ) : (
            <div className="w-full aspect-square bg-neutral-800" />
          )}
        </div>

        {/* Comments */}
        <div className="flex flex-col w-full md:w-[45%] max-h-[90vh]">
          {/* Header */}
          <div className="flex items-center gap-3 px-4 py-3 border-b border-gray-200 dark:border-neutral-700">
            <Avatar src={post.profile?.avatarUrl} username={post.profile?.username || "?"} size={32} />
            <span className="font-semibold text-sm">{post.profile?.username}</span>
          </div>

          {/* Comments list */}
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-3">
            {post.caption && (
              <div className="flex gap-3">
                <Avatar src={post.profile?.avatarUrl} username={post.profile?.username || "?"} size={32} />
                <div>
                  <span className="font-semibold text-sm mr-2">{post.profile?.username}</span>
                  <span className="text-sm">{post.caption}</span>
                </div>
              </div>
            )}
            {comments?.map((comment) => (
              <div key={comment._id} className="flex gap-3 group">
                <button onClick={() => { setProfileUsername(comment.profile?.username || null); navigate("profile"); onClose(); }}>
                  <Avatar src={comment.profile?.avatarUrl} username={comment.profile?.username || "?"} size={32} />
                </button>
                <div className="flex-1">
                  <span className="font-semibold text-sm mr-2">{comment.profile?.username}</span>
                  <span className="text-sm">{comment.text}</span>
                </div>
                {myProfile?.userId === comment.authorId && (
                  <button
                    onClick={() => deleteComment({ commentId: comment._id })}
                    className="opacity-0 group-hover:opacity-100 text-gray-400 hover:text-red-500 text-xs"
                  >
                    ×
                  </button>
                )}
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="border-t border-gray-200 dark:border-neutral-700 px-4 py-3">
            <div className="flex items-center gap-3 mb-2">
              <button onClick={handleLike}>
                <Heart size={22} strokeWidth={1.5} className={isLiked ? "fill-red-500 text-red-500" : ""} />
              </button>
            </div>
            {likesCount > 0 && (
              <p className="text-sm font-semibold mb-2">{likesCount.toLocaleString()} likes</p>
            )}
            <form onSubmit={handleSubmit} className="flex items-center gap-2">
              <input
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Add a comment..."
                className="flex-1 text-sm outline-none bg-transparent placeholder-gray-400"
              />
              <button
                type="submit"
                disabled={!text.trim()}
                className="text-blue-500 font-semibold text-sm disabled:opacity-40"
              >
                Post
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
