import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { X, ImagePlus, ChevronLeft, ChevronRight } from "lucide-react";
import { useState, useRef } from "react";
import { toast } from "sonner";

interface CreatePostModalProps {
  onClose: () => void;
}

export function CreatePostModal({ onClose }: CreatePostModalProps) {
  const generateUploadUrl = useMutation(api.posts.generateUploadUrl);
  const createPost = useMutation(api.posts.createPost);
  const [step, setStep] = useState<"select" | "edit">("select");
  const [files, setFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [caption, setCaption] = useState("");
  const [location, setLocation] = useState("");
  const [loading, setLoading] = useState(false);
  const [imgIndex, setImgIndex] = useState(0);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFiles = (selected: FileList | null) => {
    if (!selected) return;
    const arr = Array.from(selected).slice(0, 10);
    setFiles(arr);
    setPreviews(arr.map((f) => URL.createObjectURL(f)));
    setStep("edit");
  };

  const handleSubmit = async () => {
    if (files.length === 0) return;
    setLoading(true);
    try {
      const imageIds: Id<"_storage">[] = [];
      for (const file of files) {
        const url = await generateUploadUrl();
        const res = await fetch(url, { method: "POST", headers: { "Content-Type": file.type }, body: file });
        const { storageId } = await res.json();
        imageIds.push(storageId);
      }
      await createPost({ caption: caption || undefined, imageIds, location: location || undefined });
      toast.success("Post shared!");
      onClose();
    } catch (e) {
      toast.error("Failed to create post");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70" onClick={onClose}>
      <div
        className="bg-white dark:bg-neutral-900 rounded-xl overflow-hidden w-full max-w-lg relative"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 dark:border-neutral-700">
          {step === "edit" && (
            <button onClick={() => setStep("select")} className="text-sm">
              <ChevronLeft size={20} />
            </button>
          )}
          <h2 className="font-semibold text-center flex-1">
            {step === "select" ? "Create new post" : "New post"}
          </h2>
          {step === "edit" ? (
            <button
              onClick={handleSubmit}
              disabled={loading}
              className="text-sm text-blue-500 font-semibold disabled:opacity-50"
            >
              {loading ? "Sharing..." : "Share"}
            </button>
          ) : (
            <button onClick={onClose}>
              <X size={20} />
            </button>
          )}
        </div>

        {step === "select" ? (
          <div
            className="flex flex-col items-center justify-center py-20 cursor-pointer"
            onClick={() => fileRef.current?.click()}
          >
            <ImagePlus size={64} className="text-gray-300 mb-4" />
            <p className="text-xl font-light mb-4">Drag photos and videos here</p>
            <button className="bg-blue-500 text-white px-4 py-2 rounded-lg text-sm font-semibold">
              Select from computer
            </button>
            <input
              ref={fileRef}
              type="file"
              accept="image/*"
              multiple
              className="hidden"
              onChange={(e) => handleFiles(e.target.files)}
            />
          </div>
        ) : (
          <div className="flex flex-col md:flex-row">
            {/* Preview */}
            <div className="relative bg-black aspect-square md:w-[55%] flex items-center justify-center">
              {previews[imgIndex] && (
                <img src={previews[imgIndex]} alt="Preview" className="w-full h-full object-contain" />
              )}
              {previews.length > 1 && (
                <>
                  {imgIndex > 0 && (
                    <button onClick={() => setImgIndex((i) => i - 1)} className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1">
                      <ChevronLeft size={16} />
                    </button>
                  )}
                  {imgIndex < previews.length - 1 && (
                    <button onClick={() => setImgIndex((i) => i + 1)} className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1">
                      <ChevronRight size={16} />
                    </button>
                  )}
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1">
                    {previews.map((_, i) => (
                      <div key={i} className={`w-1.5 h-1.5 rounded-full ${i === imgIndex ? "bg-blue-500" : "bg-white/60"}`} />
                    ))}
                  </div>
                </>
              )}
            </div>
            {/* Form */}
            <div className="flex-1 p-4 flex flex-col gap-3">
              <textarea
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                placeholder="Write a caption..."
                rows={5}
                className="w-full text-sm outline-none resize-none bg-transparent placeholder-gray-400 border-b border-gray-200 dark:border-neutral-700 pb-3"
              />
              <input
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                placeholder="Add location"
                className="text-sm outline-none bg-transparent placeholder-gray-400 border-b border-gray-200 dark:border-neutral-700 pb-3"
              />
              <p className="text-xs text-gray-400">{files.length} photo{files.length !== 1 ? "s" : ""} selected</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
