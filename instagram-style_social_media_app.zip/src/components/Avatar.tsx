interface AvatarProps {
  src: string | null | undefined;
  username: string;
  size?: number;
  className?: string;
  ring?: boolean;
}

export function Avatar({ src, username, size = 32, className = "", ring = false }: AvatarProps) {
  const initials = username ? username[0].toUpperCase() : "?";
  const colors = [
    "from-pink-500 to-orange-400",
    "from-purple-500 to-pink-500",
    "from-blue-500 to-cyan-400",
    "from-green-400 to-teal-500",
    "from-yellow-400 to-orange-500",
  ];
  const colorIndex = username
    ? username.charCodeAt(0) % colors.length
    : 0;

  return (
    <div
      className={`rounded-full overflow-hidden flex-shrink-0 ${ring ? "ring-2 ring-pink-500 ring-offset-2 ring-offset-white dark:ring-offset-black" : ""} ${className}`}
      style={{ width: size, height: size }}
    >
      {src ? (
        <img src={src} alt={username} className="w-full h-full object-cover" />
      ) : (
        <div
          className={`w-full h-full bg-gradient-to-br ${colors[colorIndex]} flex items-center justify-center text-white font-semibold`}
          style={{ fontSize: size * 0.4 }}
        >
          {initials}
        </div>
      )}
    </div>
  );
}
