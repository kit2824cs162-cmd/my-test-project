import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { useNavigation } from "../context/NavigationContext";
import { useTheme } from "../context/ThemeContext";
import {
  Home, Search, Compass, Film, Heart, PlusSquare,
  Bookmark, Settings, Sun, Moon, LogOut, Menu
} from "lucide-react";
import { useAuthActions } from "@convex-dev/auth/react";
import { useState } from "react";
import { Avatar } from "./Avatar";

interface SidebarProps {
  onCreatePost: () => void;
}

export function Sidebar({ onCreatePost }: SidebarProps) {
  const { currentPage, navigate, setProfileUsername } = useNavigation();
  const { theme, toggleTheme } = useTheme();
  const { signOut } = useAuthActions();
  const myProfile = useQuery(api.profiles.getMyProfile);
  const unreadCount = useQuery(api.notifications.getUnreadCount);
  const [collapsed, setCollapsed] = useState(false);

  const navItems = [
    { id: "home", icon: Home, label: "Home" },
    { id: "search", icon: Search, label: "Search" },
    { id: "explore", icon: Compass, label: "Explore" },
    { id: "reels", icon: Film, label: "Reels" },
    { id: "notifications", icon: Heart, label: "Notifications", badge: unreadCount },
    { id: "create", icon: PlusSquare, label: "Create" },
  ];

  const handleNav = (id: string) => {
    if (id === "create") {
      onCreatePost();
    } else if (id === "profile") {
      setProfileUsername(myProfile?.username || null);
      navigate("profile");
    } else {
      navigate(id as any);
    }
  };

  return (
    <aside
      className={`fixed left-0 top-0 h-full z-40 border-r border-gray-200 dark:border-neutral-800 bg-white dark:bg-black flex flex-col py-4 transition-all duration-200 hidden md:flex
        ${collapsed ? "w-[72px]" : "w-[72px] lg:w-[245px]"}`}
    >
      <div className="px-3 mb-6 mt-2">
        <div className={`font-bold text-2xl px-3 py-2 hidden lg:block ${collapsed ? "lg:hidden" : ""}`}
          style={{ fontFamily: "cursive" }}>
          Instaclone
        </div>
        <div className={`lg:hidden flex justify-center`}>
          <div className="w-8 h-8 bg-gradient-to-tr from-yellow-400 via-pink-500 to-purple-600 rounded-lg" />
        </div>
      </div>

      <nav className="flex-1 flex flex-col gap-1 px-3">
        {navItems.map(({ id, icon: Icon, label, badge }) => (
          <button
            key={id}
            onClick={() => handleNav(id)}
            className={`flex items-center gap-4 px-3 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors w-full text-left relative
              ${currentPage === id ? "font-bold" : "font-normal"}`}
          >
            <div className="relative flex-shrink-0">
              <Icon size={24} strokeWidth={currentPage === id ? 2.5 : 1.5} />
              {badge ? (
                <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">
                  {badge > 9 ? "9+" : badge}
                </span>
              ) : null}
            </div>
            <span className={`hidden lg:block text-sm ${collapsed ? "lg:hidden" : ""}`}>{label}</span>
          </button>
        ))}

        {myProfile && (
          <button
            onClick={() => handleNav("profile")}
            className={`flex items-center gap-4 px-3 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors w-full text-left
              ${currentPage === "profile" ? "font-bold" : "font-normal"}`}
          >
            <Avatar src={myProfile.avatarUrl} username={myProfile.username} size={24} />
            <span className={`hidden lg:block text-sm ${collapsed ? "lg:hidden" : ""}`}>Profile</span>
          </button>
        )}
      </nav>

      <div className="px-3 flex flex-col gap-1">
        <button
          onClick={() => navigate("saved")}
          className="flex items-center gap-4 px-3 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors w-full text-left"
        >
          <Bookmark size={24} strokeWidth={1.5} />
          <span className={`hidden lg:block text-sm ${collapsed ? "lg:hidden" : ""}`}>Saved</span>
        </button>
        <button
          onClick={toggleTheme}
          className="flex items-center gap-4 px-3 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors w-full text-left"
        >
          {theme === "dark" ? <Sun size={24} strokeWidth={1.5} /> : <Moon size={24} strokeWidth={1.5} />}
          <span className={`hidden lg:block text-sm ${collapsed ? "lg:hidden" : ""}`}>
            {theme === "dark" ? "Light Mode" : "Dark Mode"}
          </span>
        </button>
        <button
          onClick={() => signOut()}
          className="flex items-center gap-4 px-3 py-3 rounded-lg hover:bg-gray-100 dark:hover:bg-neutral-800 transition-colors w-full text-left text-red-500"
        >
          <LogOut size={24} strokeWidth={1.5} />
          <span className={`hidden lg:block text-sm ${collapsed ? "lg:hidden" : ""}`}>Log out</span>
        </button>
      </div>
    </aside>
  );
}
