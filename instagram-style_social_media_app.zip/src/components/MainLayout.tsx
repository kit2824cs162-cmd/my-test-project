import { useNavigation } from "../context/NavigationContext";
import { Sidebar } from "./Sidebar";
import { HomeFeed } from "./HomeFeed";
import { ProfilePage } from "./ProfilePage";
import { NotificationsPage } from "./NotificationsPage";
import { SearchPage } from "./SearchPage";
import { CreatePostModal } from "./CreatePostModal";
import { SavedPage } from "./SavedPage";
import { ExplorePage } from "./ExplorePage";
import { ReelsPage } from "./ReelsPage";
import { MobileNav } from "./MobileNav";
import { useState } from "react";

export function MainLayout() {
  const { currentPage } = useNavigation();
  const [showCreate, setShowCreate] = useState(false);

  return (
    <div className="flex min-h-screen bg-white dark:bg-black text-black dark:text-white">
      <Sidebar onCreatePost={() => setShowCreate(true)} />
      <main className="flex-1 ml-0 md:ml-[72px] lg:ml-[245px] min-h-screen">
        {currentPage === "home" && <HomeFeed />}
        {currentPage === "explore" && <ExplorePage />}
        {currentPage === "reels" && <ReelsPage />}
        {currentPage === "notifications" && <NotificationsPage />}
        {currentPage === "search" && <SearchPage />}
        {currentPage === "profile" && <ProfilePage />}
        {currentPage === "saved" && <SavedPage />}
      </main>
      <MobileNav onCreatePost={() => setShowCreate(true)} />
      {showCreate && <CreatePostModal onClose={() => setShowCreate(false)} />}
    </div>
  );
}
