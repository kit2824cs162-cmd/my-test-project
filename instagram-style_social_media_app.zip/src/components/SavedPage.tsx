import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Bookmark } from "lucide-react";

export function SavedPage() {
  const savedPosts = useQuery(api.posts.getSavedPosts);

  return (
    <div className="max-w-[935px] mx-auto px-4 py-8 pb-20 md:pb-8">
      <h1 className="text-lg font-semibold mb-6 flex items-center gap-2">
        <Bookmark size={20} /> Saved
      </h1>

      {savedPosts === undefined ? (
        <div className="grid grid-cols-3 gap-1">
          {Array.from({ length: 9 }).map((_, i) => (
            <div key={i} className="aspect-square bg-gray-200 dark:bg-neutral-800 animate-pulse" />
          ))}
        </div>
      ) : savedPosts.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <Bookmark size={48} className="mx-auto mb-3 opacity-30" />
          <p className="text-lg font-semibold">Save photos and videos</p>
          <p className="text-sm mt-1">Save photos and videos that you want to see again.</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-1">
          {savedPosts.map((post) =>
            post ? (
              <div key={post._id} className="aspect-square overflow-hidden cursor-pointer relative group">
                {post.imageUrls[0] ? (
                  <img src={post.imageUrls[0]} alt="" className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full bg-gray-200 dark:bg-neutral-800" />
                )}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 text-white">
                  <span className="flex items-center gap-1 font-semibold">♥ {post.likesCount}</span>
                  <span className="flex items-center gap-1 font-semibold">💬 {post.commentsCount}</span>
                </div>
              </div>
            ) : null
          )}
        </div>
      )}
    </div>
  );
}
