import { useMutation, useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Id } from "../../convex/_generated/dataModel";
import { Heart, MessageCircle, Send, Bookmark, MoreHorizontal, ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import { Avatar } from "./Avatar";
import { useNavigation } from "../context/NavigationContext";
import { CommentsModal } from "./CommentsModal";
import { toast } from "sonner";

interface Post {
  _id: Id<"posts">;
  authorId: Id<"users">;
  caption?: string;
  imageUrls: string[];
  likesCount: number;
  commentsCount: number;
  isLiked: boolean;
  isSaved: boolean;
  location?: string;
  profile: {
    username: string;
    avatarUrl: string | null;
  } | null;
}

export function PostCard({ post }: { post: Post }) {
  const likePost = useMutation(api.posts.likePost);
  const unlikePost = useMutation(api.posts.unlikePost);
  const savePost = useMutation(api.posts.savePost);
  const unsavePost = useMutation(api.posts.unsavePost);
  const deletePost = useMutation(api.posts.deletePost);
  const myProfile = useQuery(api.profiles.getMyProfile);
  const { navigate, setProfileUsername } = useNavigation();
  const [imgIndex, setImgIndex] = useState(0);
  const [showComments, setShowComments] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [isLiked, setIsLiked] = useState(post.isLiked);
  const [likesCount, setLikesCount] = useState(post.likesCount);
  const [isSaved, setIsSaved] = useState(post.isSaved);

  const handleLike = async () => {
    if (isLiked) {
      setIsLiked(false);
      setLikesCount((c) => c - 1);
      await unlikePost({ postId: post._id });
    } else {
      setIsLiked(true);
      setLikesCount((c) => c + 1);
      await likePost({ postId: post._id });
    }
  };

  const handleSave = async () => {
    if (isSaved) {
      setIsSaved(false);
      await unsavePost({ postId: post._id });
    } else {
      setIsSaved(true);
      await savePost({ postId: post._id });
    }
  };

  const handleDelete = async () => {
    if (confirm("Delete this post?")) {
      await deletePost({ postId: post._id });
      toast.success("Post deleted");
    }
    setShowMenu(false);
  };

  const isOwner = myProfile?.userId === post.authorId;

  return (
    <article className="bg-white dark:bg-black border border-gray-200 dark:border-neutral-800 rounded-sm">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-3">
        <button
          className="flex items-center gap-3"
          onClick={() => { setProfileUsername(post.profile?.username || null); navigate("profile"); }}
        >
          <Avatar src={post.profile?.avatarUrl} username={post.profile?.username || "?"} size={32} ring />
          <div className="text-left">
            <p className="text-sm font-semibold leading-tight">{post.profile?.username}</p>
            {post.location && <p className="text-xs text-gray-500">{post.location}</p>}
          </div>
        </button>
        <div className="relative">
          <button onClick={() => setShowMenu(!showMenu)} className="p-1 hover:opacity-60">
            <MoreHorizontal size={20} />
          </button>
          {showMenu && (
            <div className="absolute right-0 top-8 bg-white dark:bg-neutral-800 border border-gray-200 dark:border-neutral-700 rounded-lg shadow-lg z-10 min-w-[150px] overflow-hidden">
              {isOwner && (
                <button onClick={handleDelete} className="w-full text-left px-4 py-3 text-sm text-red-500 hover:bg-gray-50 dark:hover:bg-neutral-700 font-semibold">
                  Delete
                </button>
              )}
              <button onClick={() => setShowMenu(false)} className="w-full text-left px-4 py-3 text-sm hover:bg-gray-50 dark:hover:bg-neutral-700">
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Image */}
      <div className="relative bg-black aspect-square overflow-hidden">
        {post.imageUrls.length > 0 ? (
          <img
            src={post.imageUrls[imgIndex]}
            alt="Post"
            className="w-full h-full object-cover"
            onDoubleClick={handleLike}
          />
        ) : (
          <div className="w-full h-full bg-gray-200 dark:bg-neutral-800 flex items-center justify-center">
            <span className="text-gray-400">No image</span>
          </div>
        )}
        {post.imageUrls.length > 1 && (
          <>
            {imgIndex > 0 && (
              <button
                onClick={() => setImgIndex((i) => i - 1)}
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1"
              >
                <ChevronLeft size={16} />
              </button>
            )}
            {imgIndex < post.imageUrls.length - 1 && (
              <button
                onClick={() => setImgIndex((i) => i + 1)}
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-white/80 rounded-full p-1"
              >
                <ChevronRight size={16} />
              </button>
            )}
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1">
              {post.imageUrls.map((_, i) => (
                <div key={i} className={`w-1.5 h-1.5 rounded-full ${i === imgIndex ? "bg-blue-500" : "bg-white/60"}`} />
              ))}
            </div>
          </>
        )}
      </div>

      {/* Actions */}
      <div className="px-3 pt-3 pb-1">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-3">
            <button onClick={handleLike} className="hover:opacity-60 transition-opacity">
              <Heart
                size={24}
                strokeWidth={1.5}
                className={isLiked ? "fill-red-500 text-red-500" : ""}
              />
            </button>
            <button onClick={() => setShowComments(true)} className="hover:opacity-60 transition-opacity">
              <MessageCircle size={24} strokeWidth={1.5} />
            </button>
            <button className="hover:opacity-60 transition-opacity">
              <Send size={24} strokeWidth={1.5} />
            </button>
          </div>
          <button onClick={handleSave} className="hover:opacity-60 transition-opacity">
            <Bookmark
              size={24}
              strokeWidth={1.5}
              className={isSaved ? "fill-black dark:fill-white" : ""}
            />
          </button>
        </div>

        {likesCount > 0 && (
          <p className="text-sm font-semibold mb-1">{likesCount.toLocaleString()} {likesCount === 1 ? "like" : "likes"}</p>
        )}

        {post.caption && (
          <p className="text-sm">
            <span className="font-semibold mr-1">{post.profile?.username}</span>
            {post.caption}
          </p>
        )}

        {post.commentsCount > 0 && (
          <button
            onClick={() => setShowComments(true)}
            className="text-sm text-gray-500 mt-1 hover:text-gray-700"
          >
            View all {post.commentsCount} comments
          </button>
        )}

        <button
          onClick={() => setShowComments(true)}
          className="text-xs text-gray-400 mt-1 block"
        >
          Add a comment...
        </button>
      </div>

      {showComments && (
        <CommentsModal post={post} onClose={() => setShowComments(false)} />
      )}
    </article>
  );
}
