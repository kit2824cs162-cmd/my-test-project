import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function ExplorePage() {
  const posts = useQuery(api.posts.getFeedPosts);

  return (
    <div className="max-w-[935px] mx-auto px-4 py-8 pb-20 md:pb-8">
      <h1 className="text-lg font-semibold mb-6">Explore</h1>
      {posts === undefined ? (
        <div className="grid grid-cols-3 gap-1">
          {Array.from({ length: 12 }).map((_, i) => (
            <div key={i} className="aspect-square bg-gray-200 dark:bg-neutral-800 animate-pulse" />
          ))}
        </div>
      ) : posts.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <p className="text-lg font-semibold">Nothing to explore yet</p>
          <p className="text-sm mt-1">Posts from the community will appear here.</p>
        </div>
      ) : (
        <div className="grid grid-cols-3 gap-1">
          {posts.map((post) => (
            <div key={post._id} className="aspect-square overflow-hidden cursor-pointer relative group">
              {post.imageUrls[0] ? (
                <img src={post.imageUrls[0]} alt="" className="w-full h-full object-cover" />
              ) : (
                <div className="w-full h-full bg-gray-200 dark:bg-neutral-800" />
              )}
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4 text-white">
                <span className="flex items-center gap-1 font-semibold">♥ {post.likesCount}</span>
                <span className="flex items-center gap-1 font-semibold">💬 {post.commentsCount}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
