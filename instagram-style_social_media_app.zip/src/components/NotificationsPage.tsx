import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { Avatar } from "./Avatar";
import { useNavigation } from "../context/NavigationContext";
import { useEffect } from "react";

export function NotificationsPage() {
  const notifications = useQuery(api.notifications.getNotifications);
  const markAllRead = useMutation(api.notifications.markAllRead);
  const { navigate, setProfileUsername } = useNavigation();

  useEffect(() => {
    markAllRead().catch(() => {});
  }, []);

  return (
    <div className="max-w-[600px] mx-auto px-4 py-6 pb-20 md:pb-6">
      <h1 className="text-lg font-semibold mb-6">Notifications</h1>
      {notifications === undefined ? (
        <div className="flex flex-col gap-4">
          {Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="flex items-center gap-3 animate-pulse">
              <div className="w-10 h-10 rounded-full bg-gray-200 dark:bg-neutral-700 flex-shrink-0" />
              <div className="flex-1 h-3 bg-gray-200 dark:bg-neutral-700 rounded" />
            </div>
          ))}
        </div>
      ) : notifications.length === 0 ? (
        <div className="text-center py-16 text-gray-400">
          <p className="text-lg font-semibold">No notifications yet</p>
          <p className="text-sm mt-1">When someone likes or comments on your posts, you'll see it here.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-1">
          {notifications.map((n) => (
            <div
              key={n._id}
              className={`flex items-center gap-3 px-2 py-3 rounded-lg hover:bg-gray-50 dark:hover:bg-neutral-900 cursor-pointer ${!n.read ? "bg-blue-50 dark:bg-blue-950/20" : ""}`}
              onClick={() => {
                if (n.actorProfile?.username) {
                  setProfileUsername(n.actorProfile.username);
                  navigate("profile");
                }
              }}
            >
              <Avatar
                src={n.actorProfile?.avatarUrl}
                username={n.actorProfile?.username || "?"}
                size={40}
              />
              <p className="flex-1 text-sm">
                <span className="font-semibold">{n.actorProfile?.username}</span>{" "}
                {n.type === "like" && "liked your photo."}
                {n.type === "comment" && (
                  <>commented: <span className="text-gray-500">{n.commentText}</span></>
                )}
                {n.type === "follow" && "started following you."}
              </p>
              {n.postImageUrl && (
                <img src={n.postImageUrl} alt="" className="w-10 h-10 object-cover flex-shrink-0" />
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
